# car_lane_detection
detecting car  lane  project 


to build it :  make 


to run it :  ./fc_runtime  

