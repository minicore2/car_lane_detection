#include "cv.h"  
#include "highgui.h"  
#include <iostream>
#include <opencv2/opencv.hpp>  
using namespace cv;
using namespace std;

  
int main(int argc, char *argv[])  
{  
	IplImage* img;  
        IplImage* img0;  
        IplImage* img1;  
        IplImage* img2;  
        std::string pic_name="test";
        std::string pic_new="new";
/*

   	cv::Mat image = cv::imread("test-6.jpg", CV_LOAD_IMAGE_GRAYSCALE);
    	imshow("testSrc", image);

    	if (image.empty())
    	{
        	std::cout << "read image failure" << std::endl;
        	return -1;
    	}

    	// 局部二值化  

    	int blockSize = 25;
    	int constValue = 10;
    	cv::Mat local;
    	cv::adaptiveThreshold(image, local, 255, CV_ADAPTIVE_THRESH_MEAN_C, CV_THRESH_BINARY_INV, blockSize, constValue);

    	cv::imwrite("local.jpg", local);

    	cv::imshow("localThreshold", local);
*/
        img = cvLoadImage("test-4.jpg");//默认初始图像放在工程文件下  
        
	if (NULL == img)  
            return 0;  
 
        img0 = cvCreateImage(cvGetSize(img),IPL_DEPTH_8U,1);//申请一段内存  
  
        cvCvtColor(img,img0,CV_BGR2GRAY);   
//图像数据复制  
//        cvCopy(img, img0, NULL);
        img1 = cvCreateImage(cvGetSize(img),IPL_DEPTH_8U,1);//申请一段内存  
        cvCopy(img0, img1, NULL);//数据复制，若直接赋值相当指针指向同一地址会对原本img0操作  
        img2 = cvCreateImage(cvGetSize(img),IPL_DEPTH_8U,1);//申请一段内存

//二值化操作  
        int height = img1->height;  
        int width = img1->width;  
//        int step  = img1->width;
        int step = img1->widthStep;  
        int channels = img1->nChannels; 
        bool on=true;
  
        cout<<"size : height="<<img1->height<<"  width="<<img1->width<<" widthStep="<<img1->widthStep<<" nchannels="<<img1->nChannels<<std::endl; 

        uchar *data = (uchar*)img1->imageData;  
        uchar *data2 = (uchar*)img2->imageData; 

        for(int i=0;i != height; ++ i)  
        {  
         for(int j=0;j != width; ++ j)  
         {  
             for(int k=0;k != channels; ++ k)  
             {  
                 if(data[i*step+j*channels+k]<128)  
                 {
                    data[i*step+j*channels+k]=0;//255-data[i*step+j*channels+k];  
//                   if(on==true)
//                   {
//                     printf("---value= %d  num=%d i=%d,j=%d\n",data[i*step+j*channels+k],i*step+j*channels+k,i,j);
//                      on=false;
//                   }
                 }
                 else  
                  data[i*step+j*channels+k]=255;//255-data[i*step+j*channels+k];  
             }  
         }  
        } 

// removing noise


        cvCopy(img1, img2, NULL);

//        data2[1*step+0]=255;       
//        data2[1*step+1]=255;
//        data2[1*step+2]=255;
/*
        data2[23*step+84]=0;
        data2[23*step+85]=0;
        data2[3*step+106]=0;
        data2[3*step+105]=0;
        data2[3*step+104]=0;
 //       data2[3*step+104]=0;
        data2[2*step+104]=0;

        data[23*step+84]=0;
        data[23*step+85]=0;
        data[3*step+106]=0;
        data[3*step+105]=0; 
        data[3*step+104]=0;
 //       data[3*step+104]=0;
        data[2*step+104]=0;
*/
        int height_start=  0, height_end= img1->height ; 
        int width_start=   0 , width_end=  img1->width;

        unsigned int num=0,xl=0,yl=0 ; 

        float a=0,b=0;          

	float dl=0,d=0;

        float new_d=0;

        for(int itera=0;itera<4;itera++)        
        {

        num=0;
        xl=0;
        yl=0;                 
        for(int y=height_start;y !=height_end; ++y)
        {
           for(int x=width_start;x !=width_end; ++x)  
           {
               
              printf("--- test x=%d,y=%d,data=%d \n",x,y,data2[y*step+x]);
               if(255==data[y*step+x])    
               {

                       num++;
                       xl+=x;
                       yl+=y;
//                       printf(" --- line-point x=%d y=%d xl=%d yl=%d num=%d \n",x,y,xl,yl,num);  
               }
           }
        }

        if(0==num)
        break; 

        double xi=0 , yi=0 ;  

        xi=xl/num ;
        yi=yl/num ; 

        printf("--- c-point xi=%f,yi=%f num=%d \n",xi,yi,num); 


        double ax=0,bx=0;
       
        for(int y=height_start;y !=height_end; ++y)
        {
           for(int x=width_start;x !=width_end; ++x)
           {
               if(255==data[y*step+x])
               {
                        ax+=(x-xi)*x ;
                        bx+=(y-yi)*x ;
//                        printf(" --- line-b x=%d y=%d aa=%f bb=%f  \n",x,y,(x-xi)*x,(y-yi)*x);
//                        printf(" --- line-b x=%d y=%d ax=%f bx=%f  \n",x,y,ax,bx);
               }
           }
        }


       b=bx/ax;                 
        
       a=yi-b*xi;

       printf(" ---- linx y= %f+%fx \n", a,b); 

       dl=0; 

       unsigned int dl_num=0;
       float dx=0,dy=0,di;

       for(int y=height_start;y !=height_end; ++y)
        {
           for(int x=width_start;x !=width_end; ++x)
           {
               if(255==data[y*step+x])
               {
                       dl_num++;
                       dx=abs(b*x-y+a);
                       dy=sqrt(b*b+1);
                       dl+=dx/dy ;
                       printf("--- x=%d,y=%d  distance=%g \n",x,y,dx/dy);
               }
            }

        }
         
       di=dl/dl_num;

       printf("--- di=%g dl=%g dl_num=%d \n",di,dl,dl_num);


       unsigned int test_x=52,test_y=28; 
       float test_distance=0;


       dx=abs(b*test_x-test_y+a);
       dy=sqrt(b*b+1);
       test_distance=dx/dy ;

       printf("---- test distance\n");
       printf("---- line y= %f+%fx \n", a,b);
       printf("---- point x=%d,y=%d test_d=%g \n",test_x,test_y,test_distance);
       

      float si=0,si2=0;
      unsigned s_num=0;

      for(int y=height_start;y !=height_end; ++y)
      {
           for(int x=width_start;x !=width_end; ++x)
           {
                   if(255==data[y*step+x])
                   {
                       dx=abs(b*x-y+a);
                       dy=sqrt(b*b+1);
                       d=dx/dy ;
//                       printf("--test-- d=%g \n",d);
                       si+=(d-di)*(d-di);
//                       si+=abs(d-di);
                   }
           }

       }

       si2=si/(num-1);

       printf("--- si=%g  si2=%g  \n",si,si2);

       new_d=sqrt(si2);

//       new_d=si2;

       printf("--- new_d %g \n",new_d); 

      
       for(int y=height_start;y !=height_end; y++)
        {
           for(int x=width_start;x !=width_end; x++)
           {
               if(int(a+b*x)==y)
               {
//                   if(y>(height_start+3)&&y<height_end)
//                   {
//                       data[y*step+x+2]=255;
//                       data[y*step+x+1]=255;
//                       data[y*step+x-1]=255;
//                       data[y*step+x-2]=255;
//                   }
                   data2[y*step+x]=0;
                   
               }
            }
        }

        for(int y=height_start;y !=height_end; y++)
        {
            for(int x=width_start;x !=width_end; x++)
            {     
                dx=abs(b*x-y+a);
                dy=sqrt(b*b+1);
                d=dx/dy ;      
                if(d>new_d)
                data[y*step+x]=0;
            }
        }

        pic_name+="1" ;
        pic_new+="1";
        cvNamedWindow(pic_name.c_str(), 0 );
        cvShowImage(pic_name.c_str(), img2);
        cvNamedWindow(pic_new.c_str(), 0 );
        cvShowImage(pic_new.c_str(), img1);

//        cvCopy(img1, img2, NULL); 
        }       

//创建窗口、显示图像、销毁图像、释放图像  
//        cvNamedWindow( "test1", 0 );  
//        cvShowImage("test1", img0);  
 
        cvWaitKey(0);  
  
//        cvDestroyWindow( "test1" );  
        cvDestroyWindow( "test1" );  
  
        cvReleaseImage( &img0 );  
        cvReleaseImage( &img1 );  
  
        return 0;  

}  
